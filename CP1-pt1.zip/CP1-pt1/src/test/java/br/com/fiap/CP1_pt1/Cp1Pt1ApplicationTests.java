package br.com.fiap.CP1_pt1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cp1Pt1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
