package br.com.fiap.CP1_pt1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cp1Pt1Application {

	public static void main(String[] args) {
		SpringApplication.run(Cp1Pt1Application.class, args);
	}

}
